package com.example.pixelpet

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import kotlin.math.abs
import kotlin.random.Random

class PetService : Service() {

    private enum class State { WALK, SLEEP, DRAG, FALL }

    private lateinit var wm: WindowManager
    private lateinit var pet: PetView
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var state = State.WALK
    private var tick = 0
    private var sleepTicks = 0
    private var groundY = 0

    // للسحب
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private val loop = object : Runnable {
        override fun run() {
            val screenW = resources.displayMetrics.widthPixels
            tick++
            when (state) {
                State.WALK -> {
                    lp.x += pet.dir * 10
                    if (lp.x <= 0) { lp.x = 0; pet.dir = 1 }
                    if (lp.x >= screenW - pet.width) { lp.x = screenW - pet.width; pet.dir = -1 }
                    if (tick % 4 == 0) pet.frame = 1 - pet.frame
                    // أحيانا يقف وينام (حوالي مرة كل 10 ثواني تقريبا)
                    if (Random.nextInt(170) == 0) startSleep(Random.nextInt(60, 140))
                    // أحيانا يغير اتجاهه
                    if (Random.nextInt(120) == 0) pet.dir = -pet.dir
                }
                State.SLEEP -> {
                    pet.zTick++
                    if (--sleepTicks <= 0) wake()
                }
                State.FALL -> {
                    lp.y += 35
                    if (lp.y >= groundY) { lp.y = groundY; state = State.WALK }
                }
                State.DRAG -> {}
            }
            wm.updateViewLayout(pet, lp)
            pet.invalidate()
            handler.postDelayed(this, 60)
        }
    }

    private fun startSleep(ticks: Int) {
        state = State.SLEEP
        sleepTicks = ticks
        pet.sleeping = true
        pet.zTick = 0
    }

    private fun wake() {
        pet.sleeping = false
        state = State.WALK
    }

    private fun setupTouch() {
        pet.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = e.rawX; downRawY = e.rawY
                    startX = lp.x; startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRawX
                    val dy = e.rawY - downRawY
                    if (!moved && (abs(dx) > 15 || abs(dy) > 15)) {
                        moved = true
                        pet.sleeping = false
                        state = State.DRAG
                    }
                    if (moved) {
                        val m = resources.displayMetrics
                        lp.x = (startX + dx).toInt().coerceIn(0, m.widthPixels - pet.width)
                        lp.y = (startY + dy).toInt().coerceIn(0, groundY)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) state = State.FALL                       // سابوه: يقع على الأرض
                    else if (state == State.SLEEP) wake()               // لمسة: يصحى
                    else startSleep(Random.nextInt(80, 160))            // لمسة: ينام
                    true
                }
                else -> false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(1, buildNotification())
        if (!::pet.isInitialized) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            pet = PetView(this)
            val m = resources.displayMetrics
            val petH = (15 * m.density * 5f).toInt()
            groundY = m.heightPixels - petH - 220   // غيّر 220 لو عايزه أعلى/أقل
            lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 0
                y = groundY
            }
            setupTouch()
            wm.addView(pet, lp)
            handler.post(loop)
        }
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val id = "pixelpet"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(id, "Pixel Pet", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, PetService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, id)
            .setContentTitle("Pixel Pet شغال")
            .setContentText("المس الشخصية لتنيمها، واسحبها بصباعك")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(Notification.Action.Builder(null, "إيقاف", stop).build())
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        if (::pet.isInitialized) wm.removeView(pet)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
