package com.example.pixelpet

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class PetView(ctx: Context) : View(ctx) {

    var dir = 1            // 1 = يمين, -1 = شمال
    var frame = 0          // 0 / 1 لحركة الرجلين
    var sleeping = false   // نايم؟
    var zTick = 0          // لحركة حروف Z

    private val px = resources.displayMetrics.density * 5f
    private val paint = Paint().apply { isAntiAlias = false }
    private val textPaint = Paint().apply {
        isAntiAlias = true
        color = Color.WHITE
        isFakeBoldText = true
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    private val palette = mapOf(
        'h' to Color.parseColor("#3B2314"), // شعر
        's' to Color.parseColor("#D9A066"), // بشرة
        'e' to Color.BLACK,                 // عين
        'p' to Color.parseColor("#EC6FA6"), // بلوفر
        'b' to Color.parseColor("#3F5FA8"), // بنطلون
        'k' to Color.parseColor("#222222")  // جزمة
    )

    private val top = arrayOf(
        "....hhhh....",
        "...hhhhhh...",
        "...hssssh...",
        "...hseesh...",
        "...hssssh...",
        "....ssss....",
        "...pppppp...",
        "..pppppppp..",
        "..sppppppps.",
        "..sppppppps.",
        "...pppppp..."
    )
    private val topSleep = top.copyOf().also { it[3] = "...hshhsh..." }
    private val legsA = arrayOf("...bbbbbb...", "...bb..bb...", "...bb..bb...", "...kk..kk...")
    private val legsB = arrayOf("...bbbbbb...", "....bbbb....", "....bbbb....", "....kkkk....")
    private val legsSit = arrayOf("...bbbbbb...", "..bbbbbbbb..", "..kkkkkkkk..", "............")

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension((12 * px).toInt(), (15 * px).toInt())
    }

    override fun onDraw(c: Canvas) {
        c.save()
        if (dir == -1) c.scale(-1f, 1f, width / 2f, height / 2f)
        val rows = if (sleeping) topSleep + legsSit
                   else top + (if (frame == 0) legsA else legsB)
        for ((y, row) in rows.withIndex()) {
            for ((x, ch) in row.withIndex()) {
                val color = palette[ch] ?: continue
                paint.color = color
                c.drawRect(x * px, y * px, (x + 1) * px, (y + 1) * px, paint)
            }
        }
        c.restore()

        if (sleeping) {
            val n = (zTick / 8) % 3 + 1
            textPaint.textSize = px * 2.5f
            c.drawText("z".repeat(n), width - px * 4f, px * 3f, textPaint)
        }
    }
}
